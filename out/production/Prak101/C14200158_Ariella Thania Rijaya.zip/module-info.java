module Prak101 {
    requires javafx.fxml;
    requires javafx.graphics;
    requires javafx.controls;

    opens sample;
}